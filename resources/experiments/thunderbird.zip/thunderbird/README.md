# README.md

Thunderbird sample

## Resources

- https://www.digitalocean.com/community/tutorials/how-to-remotely-access-gui-applications-using-docker-and-caddy-on-debian-9?refcode=49d9dff6b635&utm_campaign=Referral_Invite&utm_medium=Referral_Program&utm_source=CopyPaste#step-4-mdash-building-and-running-the-container
