# AI_Trading_Bot
[ESP]: Repositorio donde desarrollare los videos sobre como crear un bot de trading que use **Inteligencia artificial**.

[ENG]: This is Repository where I will be developing the videos about how to create a trading bot that uses **Artificial Inteligence**.

Check out my youtube Channel!

[ESP]: https://www.youtube.com/watch?v=XS_ykq2k3YI&list=PLuhsSjG-BPPK4i_1IgNmdvmJC8svJcqAp

[ENG]: https://www.youtube.com/watch?v=Pyelkmjmeko&list=PLJ4c1Vt75SYbenDQuLz_weJOFx3xbABSM
