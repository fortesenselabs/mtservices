# AI_MACD_RSI_EMA_BOT

[ENG]: Intelligent bot based on the **MACD**, **RSI** and **EMA**. The bot uses a **decision tree**! 

[ESP]: Bot inteligente basado en el **MACD**, **RSI** y **EMA**. El bot usa un **árbol de decisión**!

https://www.youtube.com/channel/UCWpGnaeyh0nmB-ltvp6FxIg
