public interface IAuto {
	public void accelerate();
}