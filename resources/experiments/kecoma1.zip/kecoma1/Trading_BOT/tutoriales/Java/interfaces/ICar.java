public interface ICar {
	// NO ATTRIBUTES

	// ONLY METHODS (behaviour)
	public void move();
	public void turnOff();
} 