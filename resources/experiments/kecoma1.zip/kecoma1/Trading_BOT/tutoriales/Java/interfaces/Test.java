public class Test {
    public static void main(String args[]) {
        Car c = new Car();
        c.accelerate();
        c.move();
        c.turnOff();
    }
}
