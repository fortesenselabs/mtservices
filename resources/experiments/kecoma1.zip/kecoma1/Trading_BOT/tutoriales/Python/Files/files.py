with open("ejemplo.txt", "r") as f:
    for line in f:
        print(line)