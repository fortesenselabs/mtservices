import random

l = [{ i:["aaa" for _ in range(2)] for i in range(2) } for _ in range(10)]

print(l)