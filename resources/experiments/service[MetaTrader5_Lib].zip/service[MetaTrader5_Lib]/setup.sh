#!/usr/bin/env bash

WINEPREFIX=~/.mt5 wine CMD /C setup.bat