
class RedisStore:
    """
        Store historical data, analysis and the current state of the (trading) environment including its history in Redis
    """
    def __init__(self) -> None:
        pass
