
class DataBaseStore:
    def __init__(self) -> None:
        pass

    async def get_signal(self):
        return