class TelegramNotificationInterface:
    pass