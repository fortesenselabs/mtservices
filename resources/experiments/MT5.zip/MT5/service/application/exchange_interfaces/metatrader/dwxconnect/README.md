# DWX_Connect - A simple multi-language MT4 connector

DWX_Connect provides functions to subscribe to tick and bar data, as well as to trade on MT4 or MT5 via python, java and C#. 
Its simple file-based communication also provides an easy starting point for implementations in other programming languages. 
