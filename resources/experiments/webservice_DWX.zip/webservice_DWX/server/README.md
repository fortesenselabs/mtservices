# MTWebService - A simple MT connector service

MTWebService is aa simple web server that connects to any Metatrader instance using the DWX_Connect library which provides functions to subscribe to tick and bar data, as well as to trade on MT4 or MT5 via python, java and C#. Its simple file-based communication also provides an easy starting point for implementations in other programming languages.
