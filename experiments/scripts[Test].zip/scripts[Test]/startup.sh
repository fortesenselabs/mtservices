#!/usr/bin/env bash

sleep 1s
xvfb-run wine /root/catalyst/CATALYSTMWeb.exe