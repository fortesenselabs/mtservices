#!/bin/bash

wine start /unix /home/user/.mt5/drive_c/Program\ Files/MetaTrader\ 5/terminal64.exe