#!/bin/sh
winecfg
WINEPREFIX=/root/.wine
WINEARCH=win64
-v=win10